#include "backend.h"
#include <QTimer>
#include <QTcpSocket>
#include <QProcess>

Backend::Backend(QObject *parent, QQmlApplicationEngine *ptr) : QObject{parent}
{
    qDebug() << "starting !";

    // START SERVER
    QString program = "D:\Software\miniconda3_2025\envs\MIAA39\python.exe";
    QStringList arguments;
    arguments << " D:\server_meec_lab.py";


    QProcess *myProcess = new QProcess(parent);
    myProcess->startDetached(program, arguments);

    // UI
    this->m_q2 = ptr->rootObjects().at(0)->findChild<QObject*>("quadrado");
    this->m_q2->setProperty("color", "blue");

    this->m_txt3 = ptr->rootObjects().at(0)->findChild<QObject*>("txt");
    this->m_txt3->setProperty("text", "START");
    this->m_txt3->setProperty("x", 0);
    this->m_txt3->setProperty("y", 0);

    this->m_luz = ptr->rootObjects().at(0)->findChild<QObject*>("luz");

    a = 0;
    QTimer::singleShot(1000, this, &Backend::update);

    //m_i = new INUTIL();
    //QObject::connect(this, SIGNAL(numero10()),
    //                 m_i,  SLOT(arranca()));
    //QObject::connect(m_i, SIGNAL(terminei(int)),
    //                 this,  SLOT(muda_cor(int)));

    m_serial = new QSerialPort();

    //connects
    connect(m_serial, SIGNAL(readyRead()),
            this, SLOT(ler_rs232()));

    //config QSerialPort
    m_serial->setPortName("COM3"); //ttyACM0 linux
    m_serial->setBaudRate(9600);
    m_serial->setDataBits(QSerialPort::Data8);
    m_serial->setParity(QSerialPort::NoParity);
    m_serial->setStopBits(QSerialPort::TwoStop);
    m_serial->setFlowControl(QSerialPort::NoFlowControl);

    if (m_serial->open(QIODevice::ReadWrite)) {
        qDebug() << "Connected!";
    } else {
        qDebug() << "Connection FAILED!";
    }

    // CONNECT TO SERVER FOR FIREBASE EXAMPLE

    _pSocket = new QTcpSocket( this );
    connect(_pSocket, SIGNAL(readyRead()), this, SLOT(readTcpData()) );

    _pSocket->connectToHost("localhost", 12345);
    if( _pSocket->waitForConnected() ) {
        _pSocket->write( "TCP Server ready !!" );
    }
}

void Backend::update()
{
    qDebug() << "update !";
    QTimer::singleShot(1000, this, &Backend::update);

    a++;
    this->m_txt3->setProperty("text", a);

    // example to send data to server (firebase)
    _pSocket->write( QByteArray::number(a) );

    if(a%10 == 1)
    {   qDebug() << "emit n10";
        emit numero10();
    }
}

void Backend::muda_cor(int i, QString str)
{
    qDebug() << "quem mandou foi: " << str;
    if(i==0) this->m_luz->setProperty("color","red");
    if(i==1) this->m_luz->setProperty("color","yellow");
    if(i==2) this->m_luz->setProperty("color","green");
}

void Backend::ler_rs232()
{
    if( m_serial->canReadLine() )
    {
        QByteArray raw = m_serial->readLine();
        qDebug() << "data: " << QString(raw);
    }
}

void Backend::readTcpData()
{
    if( _pSocket->canReadLine() )
    {
        QByteArray raw = _pSocket->readLine();
        qDebug() << "data TCP: " << QString(raw);
    }
}
