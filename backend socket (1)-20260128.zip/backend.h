#ifndef BACKEND_H
#define BACKEND_H

#include <QObject>
#include <QQmlApplicationEngine>

#include <QTimer>
#include <QtSerialPort/QSerialPort>
#include <QTcpSocket>

class Backend : public QObject
{
    Q_OBJECT
public:
    explicit Backend(QObject *parent = nullptr, QQmlApplicationEngine *ptr = nullptr);

signals:
    void numero10();

public slots:
    void update();
    void muda_cor(int i=0, QString str = nullptr);
    void ler_rs232();
    void readTcpData();

private:
    //INUTIL *m_i;
    QTimer m_t1;
    QObject *m_q2;
    QObject *m_txt3;
    QObject *m_luz;
    int a;

    QSerialPort *m_serial;
    QTcpSocket *_pSocket;
};

#endif // BACKEND_H
